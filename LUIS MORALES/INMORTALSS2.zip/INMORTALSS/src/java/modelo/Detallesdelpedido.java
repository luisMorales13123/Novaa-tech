
package modelo;

public class Detallesdelpedido {
     private String cantidad;
      private String precio;
      private int idDetallesdelpedido;

    public int getIdDetallesdelpedido() {
        return idDetallesdelpedido;
    }

    public void setIdDetallesdelpedido(int idDetallesdelpedido) {
        this.idDetallesdelpedido = idDetallesdelpedido;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}


package modelo;


public class Tipodedocumentocontable {
    private int idTipodedocumentocontable;

    public int getIdTipodedocumentocontable() {
        return idTipodedocumentocontable;
    }

    public void setIdTipodedocumentocontable(int idTipodedocumentocontable) {
        this.idTipodedocumentocontable = idTipodedocumentocontable;
    }
     private String descripcion;

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

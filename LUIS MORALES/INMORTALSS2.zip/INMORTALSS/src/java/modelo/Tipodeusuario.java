
package modelo;


public class Tipodeusuario {
    private String descripcion;
    private int idTipodeusuario;

    public int getIdTipodeusuario() {
        return idTipodeusuario;
    }

    public void setIdTipodeusuario(int idTipodeusuario) {
        this.idTipodeusuario = idTipodeusuario;
    }
    

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
     
}

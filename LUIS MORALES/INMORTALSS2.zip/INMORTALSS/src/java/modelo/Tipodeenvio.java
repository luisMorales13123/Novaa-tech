
package modelo;


public class Tipodeenvio {

    public int getIdtipoenvio() {
        return idtipoenvio;
    }

    public void setIdtipoenvio(int idtipoenvio) {
        this.idtipoenvio = idtipoenvio;
    }
    private String descripcion;
     private int idtipoenvio;
    

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
     
}

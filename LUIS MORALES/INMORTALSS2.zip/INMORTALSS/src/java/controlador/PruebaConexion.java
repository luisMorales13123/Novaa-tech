package controlador;

import java.sql.Connection;
import modelo.Usuario;



public class PruebaConexion {
       public static void main(String[] args) {
    Conexion con = new Conexion();

        Connection reg = con.getConn();
}
}
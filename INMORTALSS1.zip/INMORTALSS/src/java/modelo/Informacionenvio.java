
package modelo;

public class Informacionenvio {
   private String descripcion;
   private int idInformacionenvio;

    public int getIdInformacionenvio() {
        return idInformacionenvio;
    }

    public void setIdInformacionenvio(int idInformacionenvio) {
        this.idInformacionenvio = idInformacionenvio;
    }
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

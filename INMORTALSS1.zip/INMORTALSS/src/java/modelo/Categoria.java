
package modelo;


public class Categoria {
     private String descripcion;
     private int iddescripcion;

    public int getIddescripcion() {
        return iddescripcion;
    }

    public void setIddescripcion(int iddescripcion) {
        this.iddescripcion = iddescripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

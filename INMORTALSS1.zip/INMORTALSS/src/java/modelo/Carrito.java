
package modelo;


public class Carrito {
     private String informaciondelproducto;
     private int idCarrito;

    public int getIdCarrito() {
        return idCarrito;
    }

    public void setIdCarrito(int idCarrito) {
        this.idCarrito = idCarrito;
    }

    public String getInformaciondelproducto() {
        return informaciondelproducto;
    }

    public void setInformaciondelproducto(String informaciondelproducto) {
        this.informaciondelproducto = informaciondelproducto;
    }
}


package modelo;


public class Envio {
      private String descripcion;
      private String preciodeenvio;
      private int idEnvio;

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPreciodeenvio() {
        return preciodeenvio;
    }

    public void setPreciodeenvio(String preciodeenvio) {
        this.preciodeenvio = preciodeenvio;
    }


    public int getIdEnvio() {
        return idEnvio;
    }

    public void setIdEnvio(int idEnvio) {
        this.idEnvio = idEnvio;
    }
}

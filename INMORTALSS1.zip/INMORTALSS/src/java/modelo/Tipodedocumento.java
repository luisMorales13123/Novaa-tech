
package modelo;

public class Tipodedocumento {
 private int idTipodedocumento;
  private String descripcion;

    public int getIdTipodedocumento() {
        return idTipodedocumento;
    }

    public void setIdTipodedocumento(int idTipodedocumento) {
        this.idTipodedocumento = idTipodedocumento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
   
}

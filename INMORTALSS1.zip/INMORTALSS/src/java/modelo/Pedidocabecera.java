
package modelo;

public class Pedidocabecera {
    
      private int idPedidocabecera;
      private String estadodepedido;
      private String descripcion;

    public int getIdPedidocabecera() {
        return idPedidocabecera;
    }

    public void setIdPedidocabecera(int idPedidocabecera) {
        this.idPedidocabecera = idPedidocabecera;
    }

     
      
    public String getEstadodepedido() {
        return estadodepedido;
    }

    public void setEstadodepedido(String estadodepedido) {
        this.estadodepedido = estadodepedido;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

}

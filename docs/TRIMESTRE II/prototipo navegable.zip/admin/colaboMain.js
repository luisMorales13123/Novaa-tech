   // Obtener elementos del DOM
   var modal = document.getElementById('modal');
   var modalClose = document.getElementsByClassName('close')[0];
   var registroForm = document.getElementById('registroForm');
   
   // Mostrar el modal cuando se hace clic en el botón "Registrar Colaborador"
   document.getElementById('registrarBtn').addEventListener('click', function() {
     modal.style.display = 'block';
   });
   
   // Cerrar el modal cuando se hace clic en la "x" (close)
   modalClose.addEventListener('click', function() {
     modal.style.display = 'none';
   });
   
   // Registrar colaborador cuando se envía el formulario
   registroForm.addEventListener('submit', function(event) {
     event.preventDefault(); // Evitar el envío del formulario
   
     // Obtener los valores del formulario
     var nombre = document.getElementById('nombre').value;
     var correo = document.getElementById('correo').value;
     var numero = document.getElementById('numero').value;
   
     // Guardar los datos del colaborador en localStorage
     guardarColaborador(nombre, correo, numero);
   
     // Mostrar mensaje de confirmación
     alert('Colaborador registrado');
   
     // Cerrar el modal
     modal.style.display = 'none';
   
     // Limpiar el formulario
     registroForm.reset();
   });
   
   // Guardar los datos del colaborador en localStorage
   function guardarColaborador(nombre, correo, numero) {
     var colaborador = {
       nombre: nombre,
       correo: correo,
       numero: numero
     };
   
     localStorage.setItem('colaborador', JSON.stringify(colaborador));
   }
   
   // Recuperar los datos del colaborador desde localStorage
   function obtenerColaborador() {
     var colaborador = localStorage.getItem('colaborador');
     if (colaborador) {
       colaborador = JSON.parse(colaborador);
       // Aquí puedes utilizar los datos para mostrarlos en una tabla en la página actual
       console.log(colaborador);
     }
   }
   
   // Recuperar los datos del colaborador al cargar la página
   obtenerColaborador();
package PRUEBAS;

import controlador.TipodocumentoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Tipodocumento;


public class PruebaActualizarTipodocumentoDAO {


    public static void main(String[] args) throws SQLException {

  
        TipodocumentoDAO tipousuariodao = new TipodocumentoDAO();   
        Tipodocumento miayuda = new Tipodocumento ();
        Scanner leer = new Scanner (System.in);
       
        
        
     String descripcion;
     System.out.println("Por favor digite la nueva informacion del tipo de documento");
     descripcion = leer.nextLine();
     miayuda.setIdtipodocumento(1);
     miayuda.setDescripcion(descripcion);
    
     String Respuesta = tipousuariodao.actualizarTipodocumento(miayuda);
     if (Respuesta.length()== 0){
     System.out.println("La informacion fue actualizada");
     
     }else{
     
     System.out.println("Error en actualizar informacion" + Respuesta);
     }
        
    }
    }
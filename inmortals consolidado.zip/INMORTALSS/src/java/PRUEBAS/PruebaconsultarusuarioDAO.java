package PRUEBAS;
import controlador.UsuarioDAO;
import modelo.Usuario;


public class PruebaconsultarusuarioDAO {


    public static void main(String[] args) {
        
        UsuarioDAO marcadao = new UsuarioDAO();
        Usuario miUsuario = marcadao.consultarusuario(3);
        
          if (miUsuario != null) {
    
            System.out.println ("Dato encontrado:"+ miUsuario.getIdusuario()+ "-" + miUsuario.getNombre()+ "-" + miUsuario.getApellido() + "-" + miUsuario.getTelefono() + "-" + miUsuario.getDireccion() + "-" + miUsuario.getUsername() + "-" + miUsuario.getClave() + "-" + miUsuario.getTipousuario_idtipousuario() + "-" + miUsuario.getTipodocumento_idtipodocumento()  );
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}

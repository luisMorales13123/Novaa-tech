
package PRUEBAS;

import controlador.CategoriasDAO;
import java.util.Scanner;
import modelo.Categorias;


public class PRUEBAACTUALIZARcategoriaDAO {


    public static void main(String[] args) {
        CategoriasDAO marcado = new CategoriasDAO();   
        Categorias misCategorias = new Categorias ();
        Scanner leer = new Scanner (System.in);
       
        
        
     String descripcion;
     System.out.println("por favor digite la nueva descripcion de marcas");
     descripcion = leer.nextLine();
     misCategorias.setIdcategorias(2);
     misCategorias.setDescripcion(descripcion);
    
     String Respuesta = marcado.actualizarCategorias(misCategorias);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("erro en actualizar informacion" + Respuesta);
     }
    }
    
}

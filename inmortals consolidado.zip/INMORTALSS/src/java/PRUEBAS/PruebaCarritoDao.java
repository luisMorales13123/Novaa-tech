
package PRUEBAS;


import controlador.carritoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Carrito;


public class PruebaCarritoDao {


    public static void main(String[] args) throws SQLException {
    
        carritoDAO carritodao = new carritoDAO();
        Carrito micarrito = new Carrito();
        
        Scanner leer = new Scanner (System.in);
        
        
        
        int producto_idproducto = 0 ;
        String Informacionproducto ="";
        
        
        
        System.out.println("por favor ingrese la informacion del producto");
        Informacionproducto = leer.next();
        micarrito.setInformacionproducto(Informacionproducto);
        
        
        System.out.println("Ingrese el tipo de ´producto 1,2,3,4");
        producto_idproducto = leer.nextInt();
        micarrito.setProducto_idproducto(producto_idproducto);
      
      
      
       String respuesta = carritodao.adicionarCarrito(micarrito);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    }
    
package PRUEBAS;

import controlador.UsuarioDAO;
import java.util.Scanner;
import modelo.Usuario;


public class PruebaUsuarioDAO {
   
    public static void main (String[] args) {
       
        UsuarioDAO usuarioDao = new UsuarioDAO();
        Usuario misusuarios = new Usuario();
       
        Scanner leer = new Scanner (System.in);
       
        int idtipousuario = 0;
        int idtipodocumento = 0;
        String nombre = "";
        String apellido = "";
        String telefono = "" ;
        String direccion = "";
        String username = "";
        String clave = "";
       
       
        System.out.println("Ingrese los datos del usuario");
        
        System.out.println("Ingrese el nombre");
        nombre = leer.next();
        misusuarios.setNombre (nombre);
        
        System.out.println("Ingrese el apellido");
        apellido = leer.next();
        misusuarios.setApellido (apellido);
        
        System.out.println("Ingrese numero de telefono");
        telefono = leer.next();
        misusuarios.setTelefono(telefono);
        
        System.out.println("Ingrese su direccion");
        direccion = leer.next();
        misusuarios.setDireccion(direccion);
        
        System.out.println("Ingrese su username");
        username = leer.next();
        misusuarios.setUsername(username);
        
        System.out.println("Ingrese su clave");
        clave = leer.next();
        misusuarios.setClave(clave);
        
        System.out.println("Ingrese el tipodeusuario 1,2,3,4");
        idtipousuario = leer.nextInt();
        misusuarios.setTipousuario_idtipousuario(idtipousuario);
        
        System.out.println("Ingrese el tipodedocumento 1,2,3,4");
        idtipodocumento = leer.nextInt();
        misusuarios.setTipodocumento_idtipodocumento(idtipodocumento);
       
   
        String respuesta = usuarioDao.AdicionarUsuario(misusuarios);
        if (respuesta.length() == 0) {
            System.out.println("Registrado");
        }else{
            System.out.println("Error" + respuesta);
           
        }
    }
}
package PRUEBAS;



import controlador.detallespedidoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Detallespedido;
import modelo.Producto;


public class pruebaadicionardetallespedidodao {

    public static void main(String[] args) throws SQLException {
   
        detallespedidoDAO detallesdao = new detallespedidoDAO();
        Detallespedido miproducto = new Detallespedido();
        
        Scanner leer = new Scanner (System.in);
        
        String Cantidad ="";
        String precio ="";
        int pedidocabecera_idpedidocabecera= 0;
        int carrito_idcarrito = 0;
        
        
        System.out.println("por favor ingrese la cantidad");
        Cantidad = leer.next();
        miproducto.setCantidad(Cantidad);
        
        
        System.out.println("por favor ingrese el precio");
        precio = leer.next();
        miproducto.setPrecio(precio);
        
        
        System.out.println("por favor ingrese el tipo de pago 1,2,3");
        pedidocabecera_idpedidocabecera = leer.nextInt();
        miproducto.setPedidocabecera_idpedidocabecera(pedidocabecera_idpedidocabecera);
        
        System.out.println("por favor ingrese la descripcion 1,2,3");
        carrito_idcarrito = leer.nextInt();
        miproducto.setCarrito_idcarrito(carrito_idcarrito);
        
        
        
        
        
        
        
        
        
        
       String respuesta = detallesdao.adicionarDetallesdelpedido(miproducto);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

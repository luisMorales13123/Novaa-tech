/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRUEBAS;
import controlador.InfoenvioDAO;
import java.util.Scanner;
import modelo.Infoenvio;

/**
 *
 * @author Estudiante
 */
public class PruebaActualizarInfoenvioDAO {

    
    public static void main (String[] args) {
        InfoenvioDAO productodao = new InfoenvioDAO();
        Infoenvio miinfoenvio = new Infoenvio();
        Scanner leer = new Scanner (System.in);
        
        String Descripcion;
        System.out.println("Digite la descripcion del envio");
        Descripcion = leer.nextLine();
        miinfoenvio.setIdinfoenvio(1);
        miinfoenvio.setDescripcion(Descripcion);
        
        int usuario_idusuario = 0;
        System.out.println("Digite el usuario");
        usuario_idusuario  = leer.nextInt();
        miinfoenvio.setIdinfoenvio(1);
        miinfoenvio.setUsuario_idusuario(usuario_idusuario);
        

        
        String Respuesta = productodao.ActualizarInfoenvio(miinfoenvio);
        if (Respuesta.length ()==0) {
          System.out.println("la infroamcion fue actualizada");
        }else{
            
            System.out.println("error al actualizar la informacion" + Respuesta);
            
        }
    }
}       
        
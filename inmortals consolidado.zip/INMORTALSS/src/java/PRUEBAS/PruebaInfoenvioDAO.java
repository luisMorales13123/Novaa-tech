
package PRUEBAS;


import controlador.InfoenvioDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Infoenvio;



public class PruebaInfoenvioDAO {



    public static void main(String[] args) throws SQLException {
   
        InfoenvioDAO medioenviodao = new InfoenvioDAO();
         Infoenvio mimedio = new Infoenvio();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        mimedio.setDescripcion(Descripcion);
       String respuesta = medioenviodao.adicionarInformacionenvio(mimedio);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

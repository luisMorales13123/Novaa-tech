package PRUEBAS;

import controlador.InventarioDAO;
import modelo.Inventario;

public class PruebaConsultarInventarioDAO {
    public static void main(String[] args){
        
        InventarioDAO inventariodao = new InventarioDAO();
        Inventario miinventario = inventariodao.consultarInventarioDAO(1);
        
        if (miinventario != null){
            System.out.println("Dato encontrado:" + miinventario.getIdinventario()+ "-" + miinventario.getDecripcion()+ "-" + miinventario.getEntrada()+ "-" 
                    + miinventario.getSalida()+ "-" + miinventario.getCantidad()+ "-" + miinventario.getSaldo()+ "-" + miinventario.getProducto_idproducto()+ "-");
            
        } else {
            System.out.println("El dato no esta en la base de datos");
        }
    }
}
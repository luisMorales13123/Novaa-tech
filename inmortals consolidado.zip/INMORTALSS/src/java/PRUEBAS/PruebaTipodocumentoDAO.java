
package PRUEBAS;
import controlador.TipodocumentoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Tipodocumento;

public class PruebaTipodocumentoDAO {


      public static void main(String[] args) throws SQLException {
   
        TipodocumentoDAO tipodocumentodao = new TipodocumentoDAO();
        Tipodocumento midocumento = new Tipodocumento();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        midocumento.setDescripcion(Descripcion);
       String respuesta = tipodocumentodao.adicionarTipodedocumento(midocumento);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

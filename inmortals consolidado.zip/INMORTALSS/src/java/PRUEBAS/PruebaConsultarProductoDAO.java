/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRUEBAS;
import controlador.ProductoDAO;
import modelo.Producto;
/**
 *
 * @author Estudiante
 */
public class PruebaConsultarProductoDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProductoDAO productoDAO = new ProductoDAO();
        Producto miproducto = productoDAO.ConsultarProducto(1);
        
        if (miproducto != null) {
         System.out.println("Producto no encontrado:" + miproducto.getDescripcion()+ "-" + miproducto.getPrecio()+ "-" + miproducto.getCategorias_idcategorias()+ "-" + miproducto.getMarcas_idmarcas());
          
        } else {
            System.out.println("El producto no se encuentra en la base de datos");
        }
  
    }
    
}
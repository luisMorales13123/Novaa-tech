
package PRUEBAS;
import controlador.MediodepagoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Mediodepago;

public class PRUEBAmediodepagoDAO {

   
        public static void main(String[] args) throws SQLException {
   
        MediodepagoDAO mediodepagodao = new MediodepagoDAO();
        Mediodepago mimediopago = new Mediodepago();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        mimediopago.setDescripcion(Descripcion);
       String respuesta = mediodepagodao.adicionarMediodepago(mimediopago);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

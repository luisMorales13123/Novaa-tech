
package PRUEBAS;

import controlador.CategoriasDAO;
import modelo.Categorias;

public class PruebaconsultarCategoria {

   
    public static void main(String[] args) {
       CategoriasDAO marcadao = new CategoriasDAO();
        Categorias micategoria = marcadao.consultarCategoria(1);
        
          if (micategoria != null) {
    
            System.out.println ("Dato encontrado:"+ micategoria.getIdcategorias()+ "-" + micategoria.getDescripcion());
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}

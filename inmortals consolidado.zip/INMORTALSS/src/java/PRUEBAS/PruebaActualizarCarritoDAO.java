package PRUEBAS;

import controlador.carritoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Carrito;


public class PruebaActualizarCarritoDAO {


    public static void main(String[] args) throws SQLException {

  
        carritoDAO carritodao = new carritoDAO();   
        Carrito miCarrito = new Carrito ();
        Scanner leer = new Scanner (System.in);
      
  
     String informacionproducto;
     System.out.println("por favor digite la nueva informacion");
     informacionproducto = leer.nextLine();
     miCarrito.setIdcarrito(1);
     miCarrito.setInformacionproducto(informacionproducto);
     
     int producto_idproducto;
     System.out.println("por favor digite 1, 2, 3");
     producto_idproducto = leer.nextInt();
     miCarrito.setIdcarrito(1);
     miCarrito.setProducto_idproducto(producto_idproducto);
    
     String Respuesta = carritodao.actualizarCarritoDAO(miCarrito);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("error al actualizar informacion" + Respuesta);
     }
        
    }
    }
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRUEBAS;
import controlador.InfoenvioDAO;
import modelo.Infoenvio;
/**
 *
 * @author Estudiante
 */
public class PruebaConsultarInfoenvioDAO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InfoenvioDAO infoenvioDAO = new InfoenvioDAO();
        Infoenvio miinfoenvio = infoenvioDAO.ConsultarInfonevio(1);
        
        if (miinfoenvio != null) {
         System.out.println("Informacion de envio no encontrada:" + miinfoenvio.getDescripcion()+ "-" + miinfoenvio.getUsuario_idusuario());
          
        } else {
            System.out.println("la informacion de envio no se encuentra en la base de datos");
        }
    }
}
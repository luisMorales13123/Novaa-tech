package PRUEBAS;

import controlador.InventarioDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Inventario;


public class PruebaActualizarInventarioDAO {


    public static void main(String[] args) throws SQLException {

  
        InventarioDAO carritodao = new InventarioDAO();   
        Inventario miInventario = new Inventario ();
        Scanner leer = new Scanner (System.in);
      
  
     String decripcion;
     System.out.println("por favor digite la nueva informacion");
     decripcion = leer.nextLine();
     miInventario.setIdinventario(1);
     miInventario.setDecripcion(decripcion);
     
     String entrada;
     System.out.println("por favor digite la nueva informacion");
     entrada = leer.nextLine();
     miInventario.setIdinventario(1);
     miInventario.setEntrada(entrada);
     
     String salida;
     System.out.println("por favor digite la nueva informacion");
     salida = leer.nextLine();
     miInventario.setIdinventario(1);
     miInventario.setSalida(salida);
     
     String cantidad;
     System.out.println("por favor digite la nueva informacion");
     cantidad = leer.nextLine();
     miInventario.setIdinventario(1);
     miInventario.setCantidad(cantidad);
     
     String saldo;
     System.out.println("por favor digite la nueva informacion");
     saldo = leer.nextLine();
     miInventario.setIdinventario(1);
     miInventario.setSaldo(saldo);
    
     int producto_idproducto;
     System.out.println("por favor digite 1, 2, 3");
     producto_idproducto = leer.nextInt();
     miInventario.setIdinventario(1);
     miInventario.setProducto_idproducto(producto_idproducto);
     
     String Respuesta = carritodao.actualizarInventarioDAO(miInventario);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("error al actualizar informacion" + Respuesta);
     }
        
    }
    }
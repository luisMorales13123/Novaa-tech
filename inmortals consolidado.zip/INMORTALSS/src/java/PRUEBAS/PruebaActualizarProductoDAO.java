/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRUEBAS;
import controlador.ProductoDAO;
import java.util.Scanner;
import modelo.Producto;

/**
 *
 * @author Estudiante
 */
public class PruebaActualizarProductoDAO {

    
    public static void main (String[] args) {
        ProductoDAO productodao = new ProductoDAO();
        Producto miproducto = new Producto();
        Scanner leer = new Scanner (System.in);
        
        String descripcion;
        System.out.println("Digite la descripcion del producto");
        descripcion = leer.nextLine();
        miproducto.setIdproducto(2);
        miproducto.setDescripcion(descripcion);
        
        String precio;
        System.out.println("Digite el precio del producto");
        precio = leer.nextLine();
        miproducto.setIdproducto(2);
        miproducto.setDescripcion(precio);;
        
        int categorias_idcategorias = 0;
        System.out.println("Digite la categoria del producto 1,2,3,4");
        categorias_idcategorias = leer.nextInt();
        miproducto.setIdproducto(2);
        miproducto.setCategorias_idcategorias(categorias_idcategorias);
        
        int marcas_idmarcas = 0;
        System.out.println("Digite la marca 1,2,3,4");
        marcas_idmarcas = leer.nextInt();
        miproducto.setIdproducto(3);
        miproducto.setMarcas_idmarcas(marcas_idmarcas);
        
        String Respuesta = productodao.ActualizarProducto(miproducto);
        if (Respuesta.length ()==0) {
          System.out.println("la infroamcion fue actualizada");
        }else{
            
            System.out.println("error al actualizar la informacion" + Respuesta);
            
        }
    }
}
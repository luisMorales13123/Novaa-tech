package PRUEBAS;

import controlador.detallespedidoDAO;
import modelo.Detallespedido;



public class pruebaconsultardetallespedidoDAO {


    public static void main(String[] args) {
        
        detallespedidoDAO detallespedidodao = new detallespedidoDAO();
        Detallespedido midetalles = detallespedidodao.consultarDetallespedido(2);
        
          if (midetalles != null) {
    
            System.out.println ("Dato encontrado:"+ midetalles.getIddetallespedido()+ "-" + midetalles.getCantidad()+"-"+ midetalles.getPrecio()+"-"+midetalles.getPedidocabecera_idpedidocabecera()+"-"+midetalles.getCarrito_idcarrito());
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}

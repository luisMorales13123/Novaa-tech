
package PRUEBAS;

import controlador.tipodocumentocontableDAO;
import java.util.Scanner;
import modelo.Tipodocumentocontable;

public class PruebaActualizarTipodocumentocontableDAO {



    public static void main(String[] args) {
        tipodocumentocontableDAO tipodocumentocontabledao = new tipodocumentocontableDAO();   
        Tipodocumentocontable midoc= new Tipodocumentocontable ();
        Scanner leer = new Scanner (System.in);
       
        
        
     String descripcion;
     System.out.println("por favor digite la descripcion");
     descripcion = leer.nextLine();
     midoc.setIdtipodocumentocontable(1);
     midoc.setDescripcion(descripcion);
    
              
     String Respuesta = tipodocumentocontabledao.actualizarTipodocumentocontable(midoc);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("error en actualizar informacion" + Respuesta);
     }
    }
    
}

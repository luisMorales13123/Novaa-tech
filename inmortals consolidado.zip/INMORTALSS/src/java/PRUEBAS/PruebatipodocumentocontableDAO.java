
package PRUEBAS;
import controlador.tipodocumentocontableDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Tipodocumentocontable;


public class PruebatipodocumentocontableDAO {
    public static void main(String[] args) throws SQLException {
   
        tipodocumentocontableDAO tipodedocumentodao = new tipodocumentocontableDAO();
        Tipodocumentocontable mitipo = new Tipodocumentocontable();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        mitipo.setDescripcion(Descripcion);
       String respuesta = tipodedocumentodao.adicionardocumento(mitipo);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       }
    }
    }
    


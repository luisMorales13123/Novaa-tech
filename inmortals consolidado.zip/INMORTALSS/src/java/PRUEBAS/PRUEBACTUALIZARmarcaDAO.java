
package PRUEBAS;

import controlador.MarcaDAO;
import java.util.Scanner;
import modelo.Marcas;

public class PRUEBACTUALIZARmarcaDAO {



    public static void main(String[] args) {
        MarcaDAO marcado = new MarcaDAO();   
        Marcas misMarca = new Marcas ();
        Scanner leer = new Scanner (System.in);
       
        
        
     String descripcion;
     System.out.println("por favor digite la nueva descripcion de marcas");
     descripcion = leer.nextLine();
     misMarca.setIdmarcas(1);
     misMarca.setDescripcion(descripcion);
    
     String Respuesta = marcado.actualizarMarca(misMarca);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("erro en actualizar informacion" + Respuesta);
     }
    }
    
}

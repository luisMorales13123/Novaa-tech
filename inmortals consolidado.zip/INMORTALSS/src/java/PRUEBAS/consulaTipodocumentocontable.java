
package PRUEBAS;
import controlador.MarcaDAO;
import controlador.tipodocumentocontableDAO;
import modelo.Tipodocumentocontable;



public class consulaTipodocumentocontable {


    public static void main(String[] args) {
        
        tipodocumentocontableDAO docdao = new tipodocumentocontableDAO();
        Tipodocumentocontable midoc = docdao.consulaTipodocumentocontable(1);
        
          if (midoc != null) {
    
            System.out.println ("Dato encontrado:"+ midoc.getIdtipodocumentocontable()+ "-" + midoc.getDescripcion());
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}

package PRUEBAS;

import controlador.InventarioDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Inventario;

public class PruebaInventarioDAO {

    public static void main(String[] args) throws SQLException {
    
        InventarioDAO inventariodao = new InventarioDAO();
        Inventario miinventario = new Inventario();
        
        Scanner leer = new Scanner (System.in);
        
        String descripcion ="";
        String entrada ="";
        String salida ="";
        String cantidad ="";
        String saldo ="";
        int producto_idproducto = 0 ;
        
        System.out.println("por favor ingrese descripcion");
        descripcion = leer.next();
        miinventario.setDecripcion(descripcion);
        
        System.out.println("Ingrese la entrada");
        entrada = leer.next();
        miinventario.setEntrada(entrada);
        
        System.out.println("Ingrese la salida");
        salida = leer.next();
        miinventario.setSalida(salida);
        
        System.out.println("Ingrese la cantidad");
        cantidad = leer.next();
        miinventario.setCantidad(cantidad);
        
        System.out.println("Ingrese el saldo");
        saldo = leer.next();
        miinventario.setSaldo(saldo);
        
        System.out.println("Ingrese el producto");
        producto_idproducto = leer.nextInt();
        miinventario.setProducto_idproducto(producto_idproducto);
      
       String respuesta = inventariodao.adicionarInventario(miinventario);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    }
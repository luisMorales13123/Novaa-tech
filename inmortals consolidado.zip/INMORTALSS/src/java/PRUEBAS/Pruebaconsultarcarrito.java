package PRUEBAS;

import controlador.carritoDAO;
import modelo.Carrito;

public class Pruebaconsultarcarrito {
    public static void main(String[] args){
        
        carritoDAO carritodao = new carritoDAO();
        Carrito micarrito = carritodao.consultarCarritoDAO(1);
        
        if (micarrito != null){
            System.out.println("Dato encontrado:" + micarrito.getIdcarrito()+ "-" + micarrito.getInformacionproducto()+ "-" + micarrito.getProducto_idproducto());
            
        } else {
            System.out.println("El dato no esta en la base de datos");
        }
    }
}
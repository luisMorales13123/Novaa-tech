package PRUEBAS;
import controlador.TipoUsuarioDAO;
import modelo.Tipousuario;


public class PruebaConsultarTipousuarioDAO {


    public static void main(String[] args) {
        
        TipoUsuarioDAO tipousuariodao = new TipoUsuarioDAO();
        Tipousuario miayuda = tipousuariodao.consultarTipousuario(1);
        
          if (miayuda != null) {
    
            System.out.println ("Dato encontrado:"+ miayuda.getIdtipousuario()+ "-" + miayuda.getDescripcion());
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}
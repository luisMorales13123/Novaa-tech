
package PRUEBAS;

import controlador.UsuarioDAO;
import java.util.Scanner;
import modelo.Usuario;

public class PruebaACTUALIZARUsuarioDAO {



    public static void main(String[] args) {
        UsuarioDAO usuariodao = new UsuarioDAO();   
        Usuario misusuario= new Usuario ();
        Scanner leer = new Scanner (System.in);
       
        
        
     String nombre;
     System.out.println("por favor digite la nueva descripcion de nombre");
     nombre = leer.nextLine();
     misusuario.setIdusuario(3);
     misusuario.setNombre(nombre);
     
     String apellido;
     System.out.println("por favor digite la nueva descripcion de apellido");
     apellido = leer.nextLine();
     misusuario.setIdusuario(3);
     misusuario.setApellido(apellido);
     
     String telefono;
     System.out.println("por favor digite la nueva descripcion de Telefono");
     telefono = leer.nextLine();
     misusuario.setIdusuario(3);
     misusuario.setTelefono(telefono);
     
     
     String direccion;
     System.out.println("por favor digite la nueva descripcion de direccion");
     direccion = leer.nextLine();
      misusuario.setIdusuario(3);
     misusuario.setDireccion(direccion);
     
     String username;
     System.out.println("por favor digite la nueva descripcion de username");
     username = leer.nextLine();
     misusuario.setIdusuario(3);
     misusuario.setUsername(username);
     
     String clave;
     System.out.println("por favor digite la nueva descripcion de clave");
     clave = leer.nextLine();
 misusuario.setIdusuario(3);
     misusuario.setClave(clave);
      
     int tipousuario_idtipousuario = 0;
     System.out.println("por favor digite el nuevo tipo de usuario 1,2");
     tipousuario_idtipousuario = leer.nextInt();
 misusuario.setIdusuario(3);
     misusuario.setTipousuario_idtipousuario(tipousuario_idtipousuario);
     
     int tipodocumento_idtipodocumento = 0;
     System.out.println("por favor digite el nuevo tipo de documento 1,2,3,4,5");
     tipodocumento_idtipodocumento = leer.nextInt();
     misusuario.setIdusuario(3);
     misusuario.setTipodocumento_idtipodocumento(tipodocumento_idtipodocumento);
             
     
    
     String Respuesta = usuariodao.actualizarUsuario (misusuario);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("erro en actualizar informacion" + Respuesta);
     }
    }
    
}

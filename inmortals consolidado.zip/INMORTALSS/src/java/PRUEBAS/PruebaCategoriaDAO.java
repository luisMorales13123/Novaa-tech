package PRUEBAS;

import controlador.CategoriasDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Categorias;

public class PruebaCategoriaDAO {

    public static void main(String[] args) throws SQLException {
   
        CategoriasDAO categoriasdao = new CategoriasDAO();
        Categorias micategoria = new Categorias();
       
        Scanner leer = new Scanner (System.in);
       
        String Descripcion ="";
       
       
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        micategoria.setDescripcion(Descripcion);
       String respuesta = categoriasdao.adicionarCategorias(micategoria);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );

    }
   
}
}
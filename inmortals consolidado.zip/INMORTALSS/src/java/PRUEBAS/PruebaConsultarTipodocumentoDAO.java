package PRUEBAS;
import controlador.TipodocumentoDAO;
import modelo.Tipodocumento;


public class PruebaConsultarTipodocumentoDAO {


    public static void main(String[] args) {
        
        TipodocumentoDAO tipodocumentodao = new TipodocumentoDAO();
        Tipodocumento miayuda = tipodocumentodao.consultarTipodocumento(1);
        
          if (miayuda != null) {
    
            System.out.println ("Dato encontrado:"+ miayuda.getIdtipodocumento()+ "-" + miayuda.getDescripcion());
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}
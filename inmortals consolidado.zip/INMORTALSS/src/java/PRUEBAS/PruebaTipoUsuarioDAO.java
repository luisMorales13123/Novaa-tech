
package PRUEBAS;


import controlador.TipoUsuarioDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Tipousuario;

public class PruebaTipoUsuarioDAO {


    public static void main(String[] args) throws SQLException {
      
        TipoUsuarioDAO tipousuariodao = new TipoUsuarioDAO();
        Tipousuario mitipousuario = new Tipousuario();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        mitipousuario.setDescripcion(Descripcion);
       String respuesta = tipousuariodao.adicionarTipoUsuairo(mitipousuario);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

package PRUEBAS;

import controlador.TipoUsuarioDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Tipousuario;


public class PruebaActualizarTipousuarioDAO {


    public static void main(String[] args) throws SQLException {

  
        TipoUsuarioDAO tipousuariodao = new TipoUsuarioDAO();   
        Tipousuario miayuda = new Tipousuario ();
        Scanner leer = new Scanner (System.in);
       
        
        
     String descripcion;
     System.out.println("Por favor digite la nueva informacion del tipo de usuario");
     descripcion = leer.nextLine();
     miayuda.setIdtipousuario(1);
     miayuda.setDescripcion(descripcion);
    
     String Respuesta = tipousuariodao.actualizarTipousuario(miayuda);
     if (Respuesta.length()== 0){
     System.out.println("La informacion fue actualizada");
     
     }else{
     
     System.out.println("Error en actualizar informacion" + Respuesta);
     }
        
    }
    }
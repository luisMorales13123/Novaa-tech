package PRUEBAS;

import controlador.MediodepagoDAO;
import modelo.Mediodepago;

public class PruebaConsultarMediodepago {
    public static void main(String[] args){
        
        MediodepagoDAO mediodepagodao = new MediodepagoDAO();
        Mediodepago mipago = mediodepagodao.consultarMediodepagoDAO(1);
        
        if (mipago != null){
            System.out.println("Dato encontrado:" + mipago.getIdmediodepago()+ "-" + mipago.getDescripcion());
            
        } else {
            System.out.println("El dato no esta en la base de datos");
        }
    }
}
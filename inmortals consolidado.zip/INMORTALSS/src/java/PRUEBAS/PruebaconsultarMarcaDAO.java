
package PRUEBAS;
import controlador.MarcaDAO;
import modelo.Marcas;


public class PruebaconsultarMarcaDAO {


    public static void main(String[] args) {
        
        MarcaDAO marcadao = new MarcaDAO();
        Marcas miMarca = marcadao.consultarMarcas(1);
        
          if (miMarca != null) {
    
            System.out.println ("Dato encontrado:"+ miMarca.getIdmarcas()+ "-" + miMarca.getDescripcion());
             
         }else{System.out.println("no se encontro");
         
         }

    }
    
}


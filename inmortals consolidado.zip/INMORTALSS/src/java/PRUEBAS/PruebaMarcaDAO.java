
package PRUEBAS;

import controlador.MarcaDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Marcas;

public class PruebaMarcaDAO {

    public static void main(String[] args) throws SQLException {
   
        MarcaDAO marcadao = new MarcaDAO();
        Marcas mimarca = new Marcas();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        mimarca.setDescripcion(Descripcion);
       String respuesta = marcadao.adicionarMarcas(mimarca);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

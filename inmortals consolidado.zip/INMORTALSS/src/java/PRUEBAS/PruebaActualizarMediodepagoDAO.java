package PRUEBAS;

import controlador.MediodepagoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Mediodepago;


public class PruebaActualizarMediodepagoDAO {


    public static void main(String[] args) throws SQLException {

  
        MediodepagoDAO meidodepagodao = new MediodepagoDAO();   
        Mediodepago mipago = new Mediodepago();
        Scanner leer = new Scanner (System.in);
      
  
     String descripcion;
     System.out.println("por favor digite la nueva informacion");
     descripcion = leer.nextLine();
     mipago.setIdmediodepago(1);
     mipago.setDescripcion(descripcion);
     

    
     String Respuesta = meidodepagodao.actualizarMediodepagoDAO(mipago);
     if (Respuesta.length()== 0){
     System.out.println("la informacion fue actualizada");
     
     }else{
     
     System.out.println("error al actualizar informacion" + Respuesta);
     }
        
    }
    }
package PRUEBAS;


import controlador.ProductoDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Producto;

public class PruebaadicionarProducto {

    public static void main(String[] args) throws SQLException {
   
        ProductoDAO productodao = new ProductoDAO();
        Producto miproducto = new Producto();
        
        Scanner leer = new Scanner (System.in);
        
        String Descripcion ="";
        int precio = 0;
        int categorias_idcategorias  = 0 ;
        int marcas_idmarcas  = 0 ;
        
        
        System.out.println("por favor ingrese la descripcion");
        Descripcion = leer.next();
        miproducto.setDescripcion(Descripcion);
        
        System.out.println("por favor ingrese el precio");
        precio = leer.nextInt();
        miproducto.setPrecio(precio);
        
        System.out.println("por favor ingrese el tipo de categoria 1,2,3");
        categorias_idcategorias = leer.nextInt();
        miproducto.setCategorias_idcategorias(categorias_idcategorias);
        
         System.out.println("por favor ingrese el tipo de marca 1,2,3");
        marcas_idmarcas = leer.nextInt();
        miproducto.setMarcas_idmarcas(marcas_idmarcas);
        
        
        
        
        
        
       String respuesta = productodao.AdicionarProducto(miproducto);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    
}

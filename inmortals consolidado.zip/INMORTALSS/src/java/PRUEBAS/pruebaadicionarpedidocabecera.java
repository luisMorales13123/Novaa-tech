/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PRUEBAS;

import controlador.PedidoCabeceraDAO;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Pedidocabecera;

/**
 *
 * @author luis
 */
public class pruebaadicionarpedidocabecera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
       
        PedidoCabeceraDAO cabeceradao = new PedidoCabeceraDAO();
        Pedidocabecera micabecera = new Pedidocabecera();
        
        Scanner leer = new Scanner (System.in);
        
        
        
        
        String descripcion ="";
        String estadoDelPedido ="";
        int usuario_idusuario = 0 ;
        int mediodepago_idmediodepago = 0 ;
        int  tipodocumentocontable_idtipodocumentocontable = 0;
        
       System.out.println("por favor ingrese la Descripcion del producto");
        descripcion = leer.next();
        micabecera.setDescripcion(descripcion);
        
       System.out.println("por favor ingrese el Estado del producto");
        descripcion = leer.next();
        micabecera.setEstadoDelPedido(estadoDelPedido);
        
       System.out.println("por favor ingrese el Usuario 1,2,3");
        usuario_idusuario = leer.nextInt();
        micabecera.setUsuario_idusuario(usuario_idusuario);
        
      System.out.println("por favor ingrese el mediodepago 1,2,3");
        mediodepago_idmediodepago = leer.nextInt();
        micabecera.setMediodepago_idmediodepago(mediodepago_idmediodepago);
        
        System.out.println("por favor ingrese el tipodocumentocontable 1,2,3");
        tipodocumentocontable_idtipodocumentocontable = leer.nextInt();
        micabecera.setTipodocumentocontable_idtipodocumentocontable(tipodocumentocontable_idtipodocumentocontable);
        
       String respuesta = cabeceradao.adicionarpedidocabecera(micabecera);
       if (respuesta.length() == 0) {
       System.out.println("Resgistrado");
       }else{
       System.out.println("error " + respuesta );
       
       }
    }
    }
    
    


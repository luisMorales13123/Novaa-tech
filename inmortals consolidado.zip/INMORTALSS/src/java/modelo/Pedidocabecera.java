
package modelo;

public class Pedidocabecera {
private int idpedidocabecera;
private String descripcion;
private String estadoDelPedido;
private int usuario_idusuario;
private int mediodepago_idmediodepago;
private int tipodocumentocontable_idtipodocumentocontable;

    public int getIdpedidocabecera() {
        return idpedidocabecera;
    }

    public void setIdpedidocabecera(int idpedidocabecera) {
        this.idpedidocabecera = idpedidocabecera;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstadoDelPedido() {
        return estadoDelPedido;
    }

    public void setEstadoDelPedido(String estadoDelPedido) {
        this.estadoDelPedido = estadoDelPedido;
    }

    public int getUsuario_idusuario() {
        return usuario_idusuario;
    }

    public void setUsuario_idusuario(int usuario_idusuario) {
        this.usuario_idusuario = usuario_idusuario;
    }

    public int getMediodepago_idmediodepago() {
        return mediodepago_idmediodepago;
    }

    public void setMediodepago_idmediodepago(int mediodepago_idmediodepago) {
        this.mediodepago_idmediodepago = mediodepago_idmediodepago;
    }

    public int getTipodocumentocontable_idtipodocumentocontable() {
        return tipodocumentocontable_idtipodocumentocontable;
    }

    public void setTipodocumentocontable_idtipodocumentocontable(int tipodocumentocontable_idtipodocumentocontable) {
        this.tipodocumentocontable_idtipodocumentocontable = tipodocumentocontable_idtipodocumentocontable;
    }
    

}


package modelo;

public class Detallespedido {
private int iddetallespedido;
private String cantidad;
private String precio;
private int pedidocabecera_idpedidocabecera ;
private int carrito_idcarrito ;

    public int getIddetallespedido() {
        return iddetallespedido;
    }

    public void setIddetallespedido(int iddetallespedido) {
        this.iddetallespedido = iddetallespedido;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public int getPedidocabecera_idpedidocabecera() {
        return pedidocabecera_idpedidocabecera;
    }

    public void setPedidocabecera_idpedidocabecera(int pedidocabecera_idpedidocabecera) {
        this.pedidocabecera_idpedidocabecera = pedidocabecera_idpedidocabecera;
    }

    public int getCarrito_idcarrito() {
        return carrito_idcarrito;
    }

    public void setCarrito_idcarrito(int carrito_idcarrito) {
        this.carrito_idcarrito = carrito_idcarrito;
    }


}

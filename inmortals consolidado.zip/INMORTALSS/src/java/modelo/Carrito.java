
package modelo;


public class Carrito {

    public int getIdcarrito() {
        return idcarrito;
    }

    public void setIdcarrito(int idcarrito) {
        this.idcarrito = idcarrito;
    }

    public String getInformacionproducto() {
        return informacionproducto;
    }

    public void setInformacionproducto(String informacionproducto) {
        this.informacionproducto = informacionproducto;
    }

    public int getProducto_idproducto() {
        return producto_idproducto;
    }

    public void setProducto_idproducto(int producto_idproducto) {
        this.producto_idproducto = producto_idproducto;
    }
private int idcarrito;
private String informacionproducto;
private int producto_idproducto;
}


package modelo;

public class Mediodepago {
private int idmediodepago;
private String descripcion;


    public int getIdmediodepago() {
        return idmediodepago;
    }

    public void setIdmediodepago(int idmediodepago) {
        this.idmediodepago = idmediodepago;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }



}

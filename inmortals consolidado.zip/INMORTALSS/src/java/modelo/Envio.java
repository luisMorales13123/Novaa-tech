
package modelo;


public class Envio {
private int idenvio;
private String descripcion;
private String precioenvio;
private int pedidocabecera_idpedidocabecera;
private int medioenvio_idmedioenvio;


    public int getIdenvio() {
        return idenvio;
    }

    public void setIdenvio(int idenvio) {
        this.idenvio = idenvio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrecioenvio() {
        return precioenvio;
    }

    public void setPrecioenvio(String precioenvio) {
        this.precioenvio = precioenvio;
    }

    public int getPedidocabecera_idpedidocabecera() {
        return pedidocabecera_idpedidocabecera;
    }

    public void setPedidocabecera_idpedidocabecera(int pedidocabecera_idpedidocabecera) {
        this.pedidocabecera_idpedidocabecera = pedidocabecera_idpedidocabecera;
    }

    public int getMedioenvio_idmedioenvio() {
        return medioenvio_idmedioenvio;
    }

    public void setMedioenvio_idmedioenvio(int medioenvio_idmedioenvio) {
        this.medioenvio_idmedioenvio = medioenvio_idmedioenvio;
    }


}

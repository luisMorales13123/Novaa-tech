
package modelo;

public class Infoenvio {
private int idinfoenvio;
private String Descripcion;
private int usuario_idusuario;

    public int getIdinfoenvio() {
        return idinfoenvio;
    }

    public void setIdinfoenvio(int idinfoenvio) {
        this.idinfoenvio = idinfoenvio;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public int getUsuario_idusuario() {
        return usuario_idusuario;
    }

    public void setUsuario_idusuario(int usuario_idusuario) {
        this.usuario_idusuario = usuario_idusuario;
    }

}

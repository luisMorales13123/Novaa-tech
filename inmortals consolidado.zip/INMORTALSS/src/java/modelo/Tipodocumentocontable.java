
package modelo;


public class Tipodocumentocontable {
private int idtipodocumentocontable;
private String descripcion;

    public int getIdtipodocumentocontable() {
        return idtipodocumentocontable;
    }

    public void setIdtipodocumentocontable(int idtipodocumentocontable) {
        this.idtipodocumentocontable = idtipodocumentocontable;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }








}

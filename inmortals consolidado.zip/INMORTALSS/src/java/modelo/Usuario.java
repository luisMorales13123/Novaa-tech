
package modelo;


public class Usuario {
    private int idusuario;
    private String nombre;
    private String apellido;
    private String telefono;
    private String direccion;
    private String username;
    private String clave;   
    private int tipousuario_idtipousuario;
    private int tipodocumento_idtipodocumento;
    
    
    
    public int getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public int getTipousuario_idtipousuario() {
        return tipousuario_idtipousuario;
    }

    public void setTipousuario_idtipousuario(int tipousuario_idtipousuario) {
        this.tipousuario_idtipousuario = tipousuario_idtipousuario;
    }

    public int getTipodocumento_idtipodocumento() {
        return tipodocumento_idtipodocumento;
    }

    public void setTipodocumento_idtipodocumento(int tipodocumento_idtipodocumento) {
        this.tipodocumento_idtipodocumento = tipodocumento_idtipodocumento;
    }

   



}

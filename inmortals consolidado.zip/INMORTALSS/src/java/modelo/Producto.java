
package modelo;


public class Producto {
private int idproducto ;
private String descripcion	;
private int precio;
private int categorias_idcategorias;
private int marcas_idmarcas;


    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCategorias_idcategorias() {
        return categorias_idcategorias;
    }

    public void setCategorias_idcategorias(int categorias_idcategorias) {
        this.categorias_idcategorias = categorias_idcategorias;
    }

    public int getMarcas_idmarcas() {
        return marcas_idmarcas;
    }

    public void setMarcas_idmarcas(int marcas_idmarcas) {
        this.marcas_idmarcas = marcas_idmarcas;
    }


}

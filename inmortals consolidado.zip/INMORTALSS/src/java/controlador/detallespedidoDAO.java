
package controlador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Detallespedido;

public class detallespedidoDAO {
     
    public String adicionarDetallesdelpedido(Detallespedido mipedido) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO detallespedido (cantidad,precio,pedidocabecera_idpedidocabecera,carrito_idcarrito)"
                    + " VALUES (? , ?,?,?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, mipedido.getCantidad());
            sentencia.setString(2, mipedido.getPrecio());
            sentencia.setInt   (3, mipedido.getPedidocabecera_idpedidocabecera());
            sentencia.setInt   (4,mipedido.getCarrito_idcarrito());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en MarcaDAO" + ex.getMessage());
        }
    return miRespuesta;
        
        
}
    
    
    
    public Detallespedido consultarDetallespedido(int iddetallespedido) {
        Detallespedido midepeddido = null;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String querymarcas = " select iddetallespedido,cantidad,precio,pedidocabecera_idpedidocabecera,carrito_idcarrito " + " from detallespedido where iddetallespedido = '"+iddetallespedido+"';";
            ResultSet rs = sentencia.executeQuery(querymarcas);
            
            while (rs.next()) {
                midepeddido = new Detallespedido();
                midepeddido.setIddetallespedido(rs.getInt(1));
                midepeddido.setCantidad(rs.getString(2));
                midepeddido.setPrecio(rs.getString(3));
                midepeddido.setPedidocabecera_idpedidocabecera(rs.getInt(4));
                midepeddido.setCarrito_idcarrito(rs.getInt(5));
            }

            return midepeddido;
        } catch (Exception ex) {
            System.out.println("Error consulta marcaconsultarDAO:" + ex.getMessage());
            return midepeddido;

        }
    }
}

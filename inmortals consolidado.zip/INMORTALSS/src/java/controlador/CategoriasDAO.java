package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Categorias;


public class CategoriasDAO {
   
   
    public String adicionarCategorias (Categorias perfil) throws SQLException {
     
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
       
       
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO categorias (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en CategoriasDAO" + ex.getMessage());
        }
    return miRespuesta;
    }
    
    
     public Categorias consultarCategoria(int idcategorias) {
        Categorias micategoria = null;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String querymarcas = " select idcategorias,descripcion " + " from categorias where idcategorias = '"+idcategorias+"';";
            ResultSet rs = sentencia.executeQuery(querymarcas);
            
            while (rs.next()) {
                micategoria = new Categorias();
                micategoria.setIdcategorias(rs.getInt(1));
                micategoria.setDescripcion(rs.getString(2));
            }

            return micategoria;
        } catch (Exception ex) {
            System.out.println("Error consulta categoriaconsultarDAO:" + ex.getMessage());
            return micategoria;

        }
    
}
     public String actualizarCategorias (Categorias micategoria){
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update categorias set Descripcion = ? " + " where idcategorias = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,micategoria.getDescripcion());
            sentencia.setInt(2,micategoria.getIdcategorias());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en marca.actualizar\n" + ex.getMessage());
        }
        return miRespuesta;
    }
}


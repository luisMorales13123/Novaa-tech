
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Tipousuario;

public class TipoUsuarioDAO {
        public String adicionarTipoUsuairo(Tipousuario perfil) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO tipousuario (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en TipodeUsiarioDAO" + ex.getMessage());
        }
    return miRespuesta;
        
        
}
             public Tipousuario consultarTipousuario(int idtipousuario) {
        Tipousuario miayuda = null;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            
            Statement sentencia = nuevaCon.createStatement();
            String querymarcas = " select idtipousuario,descripcion " + " from tipousuario where idtipousuario = '"+idtipousuario+"';";
            ResultSet rs = sentencia.executeQuery(querymarcas);
            
            while (rs.next()) {
                miayuda = new Tipousuario();
                miayuda.setIdtipousuario(idtipousuario);
                miayuda.setDescripcion(rs.getString(2));
            }

            return miayuda;
        } catch (Exception ex) {
            System.out.println("Error consulta TipousuarioDAO:" + ex.getMessage());
            return miayuda;

        }
    }
        
        
        
        
        
        
        
    public String actualizarTipousuario (Tipousuario miayuda){
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update tipousuario set Descripcion = ? " + " where Idtipousuario = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,miayuda.getDescripcion());
            sentencia.setInt(2,miayuda.getIdtipousuario());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en tipousuario.actualizar\n" + ex.getMessage());
        }
        return miRespuesta;
    }
}

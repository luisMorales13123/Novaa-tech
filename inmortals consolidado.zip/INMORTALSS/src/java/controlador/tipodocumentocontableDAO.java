
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Tipodocumentocontable;


public class tipodocumentocontableDAO {
     public String adicionardocumento(Tipodocumentocontable perfil) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO tipodocumentocontable (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en tipodocumentocontableDAO" + ex.getMessage());
        }
    return miRespuesta;
        
        
}
     
     
     public Tipodocumentocontable consulaTipodocumentocontable(int idtipodocumentocontable) {
        Tipodocumentocontable miTipodocumentocontable = null;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String querymarcas = " select idtipodocumentocontable ,descripcion " + " from tipodocumentocontable where idtipodocumentocontable = '"+idtipodocumentocontable+"';";
            ResultSet rs = sentencia.executeQuery(querymarcas);
            
            while (rs.next()) {
                miTipodocumentocontable = new Tipodocumentocontable();
                miTipodocumentocontable.setIdtipodocumentocontable(rs.getInt(1));
                miTipodocumentocontable.setDescripcion(rs.getString(2));
            }

            return miTipodocumentocontable;
        } catch (Exception ex) {
            System.out.println("Error consulta marcaconsultarDAO:" + ex.getMessage());
            return miTipodocumentocontable;

        }
    }

    public String actualizarTipodocumentocontable (Tipodocumentocontable midoc){
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
           String Query = " update Tipodocumentocontable set descripcion" + " where idtipodocumentocontable  = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            
            sentencia.setString(1,midoc.getDescripcion());
            sentencia.setInt(2,midoc.getIdtipodocumentocontable());

            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en TipodocumentocontableDAO.actualizar\n" + ex.getMessage());
        }
        return miRespuesta;
    }
  
  
  
  
  
}


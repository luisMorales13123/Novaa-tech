
package controlador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Mediodepago;
public class MediodepagoDAO {


    
     public String adicionarMediodepago(Mediodepago perfil) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO mediodepago (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en mediodepagoDAO" + ex.getMessage());
        }
    return miRespuesta;
}
    

public Mediodepago consultarMediodepagoDAO(int idmediodepago ){ 
   Mediodepago mipago = null;
        
    Conexion miConexion = new Conexion ();
    Connection nuevaCon;
    nuevaCon = miConexion.getConn();
        
    try {
        Statement sentencia = nuevaCon.createStatement();
        String querycarrito = " select idmediodepago  , descripcion" + "from mediodepago where idmediodepago  = " + idmediodepago  + ";";
        ResultSet rs = sentencia.executeQuery(querycarrito);
    
        while (rs.next()){
    
        mipago = new Mediodepago ();
        mipago.setIdmediodepago(rs.getInt(1));
        mipago.setDescripcion(rs.getString(2));     
        }
        
      return mipago;
    } catch (Exception ex){
      System.out.println("Error ConsultarMediodepagoDAO:" + ex.getMessage());
      return mipago;
    }
}

public String actualizarMediodepagoDAO (Mediodepago mipago){
        
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update mediodepago set descripcion = ? " + " where idmediodepago = ?;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,mipago.getDescripcion());
            sentencia.setInt(2,mipago.getIdmediodepago());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarMediodepagoDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    } 
}


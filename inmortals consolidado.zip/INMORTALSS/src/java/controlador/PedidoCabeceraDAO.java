
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Pedidocabecera;


public class PedidoCabeceraDAO {
    public String adicionarpedidocabecera(Pedidocabecera micabecera) throws SQLException { 
     
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO pedidocabecera (descripcion,estadoDelPedido,usuario_idusuario,mediodepago_idmediodepago,tipodocumentocontable_idtipodocumentocontable)"
                    + " VALUES (?,?,?,?,?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, micabecera.getDescripcion());
            sentencia.setString(2,micabecera.getEstadoDelPedido());
            sentencia.setInt (3,micabecera.getUsuario_idusuario());
            sentencia.setInt (4,micabecera.getMediodepago_idmediodepago());
            sentencia.setInt (5,micabecera.getTipodocumentocontable_idtipodocumentocontable());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en pedidocabeceraDAO" + ex.getMessage());
        }
    return miRespuesta;
        
    
    
    
}

}


package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Tipodocumento;


public class TipodocumentoDAO {
        public String adicionarTipodedocumento(Tipodocumento perfil) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO tipodocumento (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en MarcaDAO" + ex.getMessage());
        }
    return miRespuesta;
        
        
}
        public Tipodocumento consultarTipodocumento(int idtipodocumento) {
        Tipodocumento miayuda = null;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            
            Statement sentencia = nuevaCon.createStatement();
            String querymarcas = " select idtipodocumento,descripcion " + " from tipodocumento where idtipodocumento = '"+idtipodocumento+"';";
            ResultSet rs = sentencia.executeQuery(querymarcas);
            
            while (rs.next()) {
                miayuda = new Tipodocumento();
                miayuda.setIdtipodocumento(idtipodocumento);
                miayuda.setDescripcion(rs.getString(2));
            }

            return miayuda;
        } catch (Exception ex) {
            System.out.println("Error consulta TipodocumentoDAO:" + ex.getMessage());
            return miayuda;

        }
    }
        
        
        
        
        
        
        
    public String actualizarTipodocumento (Tipodocumento miayuda){
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update tipodocumento set Descripcion = ? " + " where Idtipodocumento = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,miayuda.getDescripcion());
            sentencia.setInt(2,miayuda.getIdtipodocumento());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en Tipodocumento.actualizar\n" + ex.getMessage());
        }
        return miRespuesta;
    }
}

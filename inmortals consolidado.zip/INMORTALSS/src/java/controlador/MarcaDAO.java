
package controlador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import modelo.Marcas;
public class MarcaDAO {

    
    public String adicionarMarcas(Marcas miMarca) throws SQLException { 
     
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO marcas (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, miMarca.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en MarcaDAO" + ex.getMessage());
        }
    return miRespuesta;
        
    
    
    
}

    
    
   
    public Marcas consultarMarcas(int idmarcas) {
        Marcas mimarca = null;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String querymarcas = " select idmarcas,descripcion " + " from marcas where idmarcas = '"+idmarcas+"';";
            ResultSet rs = sentencia.executeQuery(querymarcas);
            
            while (rs.next()) {
                mimarca = new Marcas();
                mimarca.setIdmarcas(rs.getInt(1));
                mimarca.setDescripcion(rs.getString(2));
            }

            return mimarca;
        } catch (Exception ex) {
            System.out.println("Error consulta marcaconsultarDAO:" + ex.getMessage());
            return mimarca;

        }
    }
    public String actualizarMarca (Marcas mimarca){
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update marcas set Descripcion = ? " + " where idmarcas = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
             sentencia.setInt(1,mimarca.getIdmarcas());
            sentencia.setString(2,mimarca.getDescripcion());
     
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en marca.actualizar\n" + ex.getMessage());
        }
        return miRespuesta;
    }
  
}





 







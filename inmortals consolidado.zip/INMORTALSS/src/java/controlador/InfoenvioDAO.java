
package controlador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Infoenvio;



public class InfoenvioDAO {
    
    
    
    public String adicionarInformacionenvio(Infoenvio perfil) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO medioenvio (Descripcion)"
                    + " VALUES (?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getDescripcion());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en MedioEnvioDAO" + ex.getMessage());
        }
    return miRespuesta;
        
        
}
      public  Infoenvio ConsultarInfonevio (int idinfoenvio ){
     Infoenvio miinfoenvio = null;
     Conexion miConexion = new Conexion ();
     Connection nuevaCon;
     nuevaCon = miConexion.getConn();
     
try{
    Statement sentencia = nuevaCon.createStatement();
    String queryinfoenvio = "select idinfoenvio ,Descripcion,usuario_idusuario " + "from infoenvio where idinfoenvio = '" + idinfoenvio + "';";
    ResultSet rs = sentencia.executeQuery(queryinfoenvio);
    while (rs.next()){
        miinfoenvio = new Infoenvio();
        miinfoenvio.setIdinfoenvio(rs.getInt(1));
        miinfoenvio.setDescripcion(rs.getString(2));
        miinfoenvio.setUsuario_idusuario(rs.getInt(3));;
    }
    return miinfoenvio;
} catch (Exception ex) {
    System.err.println("Error consulta InfoenvioDAO_ConsultarInfoenvioDAO\n" + ex.getMessage());
    return miinfoenvio;
}
  }


public String ActualizarInfoenvio (Infoenvio miinfoenvio) {
    String miRespuesta;
    Conexion miConexion = new Conexion ();
    Connection nuevacon;
    nuevacon = miConexion.getConn();
    
    PreparedStatement sentencia;
    
    try{
        String query = "update infoenvio set Descripcion = ?, usuario_idusuario = ?" + " where idinfoenvio = ? ;";
        sentencia = nuevacon.prepareStatement(query);
        
        sentencia.setString(1,miinfoenvio.getDescripcion());
        sentencia.setInt(2,miinfoenvio.getUsuario_idusuario());
        sentencia.setInt(3,miinfoenvio.getIdinfoenvio());
 
        sentencia.executeUpdate ();
        System.out.println("Query" + sentencia.toString());
        miRespuesta = "";
    } catch (Exception ex){
        miRespuesta = ex.getMessage ();
        System.out.println("Error Actualizar InfoenvioDAO_ActualizarInfoenvio\n" + ex.getMessage());
    }
    return miRespuesta;
    }
}


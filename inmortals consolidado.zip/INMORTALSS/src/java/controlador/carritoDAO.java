
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Carrito;


public class carritoDAO {
        public String adicionarCarrito(Carrito perfil) throws SQLException {
      
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO carrito (informacionproducto,producto_idproducto)"
                    + " VALUES (?,?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, perfil.getInformacionproducto());
            sentencia.setInt (2,perfil.getProducto_idproducto());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en carritoDAO" + ex.getMessage());
        }
    return miRespuesta;
        
        
}
        public Carrito consultarCarritoDAO(int idcarrito){ 
   Carrito miCarrito = null;
        
    Conexion miConexion = new Conexion ();
    Connection nuevaCon;
    nuevaCon = miConexion.getConn();
        
    try {
        Statement sentencia = nuevaCon.createStatement();
        String querycarrito = " select idcarrito , informacionproducto, producto_idproducto " + "from carrito where idcarrito = " + idcarrito + ";";
        ResultSet rs = sentencia.executeQuery(querycarrito);
    
        while (rs.next()){
    
        miCarrito = new Carrito ();
        miCarrito.setIdcarrito(rs.getInt(1));
        miCarrito.setInformacionproducto(rs.getString(2));
        miCarrito.setProducto_idproducto(rs.getInt(3));      
        }
        
      return miCarrito;
    } catch (Exception ex){
      System.out.println("Error consulta condultarCarritoDAO:" + ex.getMessage());
      return miCarrito;
    }
    
    
}
        
        
        public String actualizarCarritoDAO (Carrito micarrito){
        
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update carrito set informacionproducto = ?, producto_idproducto = ? " + " where idcarrito = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,micarrito.getInformacionproducto());
            sentencia.setInt(2,micarrito.getProducto_idproducto());
            sentencia.setInt(3,micarrito.getIdcarrito());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en Actualizarcarrito\n" + ex.getMessage());
        }
        return miRespuesta;
    } 

}
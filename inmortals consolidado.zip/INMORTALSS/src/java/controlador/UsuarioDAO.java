package controlador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import modelo.Usuario;

       

public class UsuarioDAO {
   
    public String AdicionarUsuario (Usuario miusuario) {
            String miRespuesta;
            Conexion miConexion = new Conexion();
            Connection nuevaCon;
            nuevaCon = miConexion.getConn();
           
            PreparedStatement sentencia;
           
            try {
                String Query = "INSERT INTO Usuario (nombre,apellido,telefono,direccion,username,clave,tipousuario_idtipousuario,tipodocumento_idtipodocumento)"
                        + " VALUES (?,?,?,?,?,?,?,?);";
                sentencia = nuevaCon.prepareStatement (Query);
                sentencia.setString (1,miusuario.getNombre());
                sentencia.setString (2,miusuario.getApellido());
                sentencia.setString(3, miusuario.getTelefono());
                sentencia.setString (4,miusuario.getDireccion());
                sentencia.setString (5,miusuario.getUsername());
                sentencia.setString (6,miusuario.getClave());
                 sentencia.setInt (7,miusuario.getTipousuario_idtipousuario());
                sentencia.setInt (8,miusuario.getTipodocumento_idtipodocumento());
                sentencia.execute();
                miRespuesta = ""; 
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en UsuarioDAO" + ex.getMessage());
        }
    return miRespuesta;
    
}

      

 
  public  Usuario consultarusuario (int idusuario){
     Usuario miusuario = null;
     Conexion miConexion = new Conexion ();
     Connection nuevaCon;
     nuevaCon = miConexion.getConn();
     
     try{
         
       Statement sentencia = nuevaCon.createStatement();
       String queryusuario = "select idusuario, nombre, apellido, telefono, direccion, username, clave,tipousuario_idtipousuario ,tipodocumento_idtipodocumento " +
               "from usuario where  idusuario = '"+idusuario+"';";
       ResultSet rs = sentencia.executeQuery(queryusuario);
       
  
       while (rs.next()){
           miusuario = new Usuario ();
           miusuario.setIdusuario(rs.getInt(1));
           miusuario.setNombre(rs.getString(2));
           miusuario.setApellido(rs.getString(3));
           miusuario.setTelefono(rs.getString(4));
           miusuario.setDireccion(rs.getString(5));
           miusuario.setUsername(rs.getString(6));
           miusuario.setClave(rs.getString(7));
           miusuario.setTipousuario_idtipousuario(rs.getInt(8));
           miusuario.setTipodocumento_idtipodocumento(rs.getInt(9));
       }
       
       
 return miusuario;
       }catch (Exception ex){
       System.out.println("Error consultarUsuarioDAO" + ex.getMessage());
       return miusuario;
       }
     
     }
    public String actualizarUsuario (Usuario miUsuario){
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
           String Query = " update usuario set Nombre = ? , Apellido = ? , Telefono = ? , Direccion = ? , Username = ? , Clave = ? , Tipousuario_idtipousuario  = ? , Tipodocumento_idtipodocumento = ? " + " where idusuario  = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            
            sentencia.setString(1,miUsuario.getNombre());
            sentencia.setString(2,miUsuario.getApellido());
            sentencia.setString(3,miUsuario.getTelefono());
            sentencia.setString(4,miUsuario.getDireccion());
            sentencia.setString(5,miUsuario.getUsername());
            sentencia.setString(6,miUsuario.getClave());
            sentencia.setInt(7,miUsuario.getTipousuario_idtipousuario());
            sentencia.setInt(8,miUsuario.getTipodocumento_idtipodocumento());
            sentencia.setInt(9,miUsuario.getIdusuario());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en usuario.actualizar\n" + ex.getMessage());
        }
        return miRespuesta;
    }
  
  
  
  
  
}

package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Inventario;

public class InventarioDAO {
  
    public String adicionarInventario(Inventario ayudaInventario) throws SQLException { 
     
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        
        PreparedStatement sentencia;
        try {
            String  Query = "INSERT INTO inventario (decripcion, entrada, salida, cantidad, saldo, producto_idproducto )"
                    + " VALUES (?,?,?,?,?,?);";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1, ayudaInventario.getDecripcion());
            sentencia.setString(2, ayudaInventario.getEntrada());
            sentencia.setString(3, ayudaInventario.getSalida());
            sentencia.setString(4, ayudaInventario.getCantidad());
            sentencia.setString(5, ayudaInventario.getSaldo());
            sentencia.setInt(6, ayudaInventario.getProducto_idproducto());
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en InventarioDAO" + ex.getMessage());
        }
    return miRespuesta;  
}

public Inventario consultarInventarioDAO(int idinventario){ 
   Inventario miInventario = null;
        
    Conexion miConexion = new Conexion ();
    Connection nuevaCon;
    nuevaCon = miConexion.getConn();
        
    try {
        Statement sentencia = nuevaCon.createStatement();
        String queryinventario = " select idinventario ,decripcion,entrada,salida,cantidad,saldo,producto_idproducto  " + "from inventario where idinventario = " + idinventario + ";";
        ResultSet rs = sentencia.executeQuery(queryinventario);
    
        while (rs.next()){
    
        miInventario = new Inventario ();
        miInventario.setIdinventario(rs.getInt(1));
        miInventario.setDecripcion(rs.getString(2));
        miInventario.setEntrada(rs.getString(3));
        miInventario.setSalida(rs.getString(4));  
        miInventario.setCantidad(rs.getString(5));  
        miInventario.setSaldo(rs.getString(6));  
        miInventario.setProducto_idproducto(rs.getInt(7));  
        }
        
      return miInventario;
    } catch (Exception ex){
      System.out.println("Error consulta condultarInventarioDAO:" + ex.getMessage());
      return miInventario;
    }
}

    public String actualizarInventarioDAO (Inventario miinventario){
        
        String miRespuesta;
        Conexion miConexion = new Conexion ();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try{ 
            String Query = " update inventario set descripcion = ?, entrada = ?, salida = ?, cantidad = ?, saldo = ?, producto_idproducto = ?, " + " where idinventario = ? ;";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,miinventario.getDecripcion());
            sentencia.setString(2,miinventario.getEntrada());
            sentencia.setString(3,miinventario.getSalida());
            sentencia.setString(4,miinventario.getCantidad());
            sentencia.setString(5,miinventario.getSaldo());
            sentencia.setInt(6,miinventario.getProducto_idproducto());
            sentencia.setInt(7,miinventario.getIdinventario());
            
            sentencia.executeUpdate();
            System.out.println("Query" + sentencia.toString());
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ActualizarInventario\n" + ex.getMessage());
        }
        return miRespuesta;
    } 
}
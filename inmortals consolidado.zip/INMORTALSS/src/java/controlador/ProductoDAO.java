package controlador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import modelo.Producto;

       

public class ProductoDAO {
   
    public String AdicionarProducto (Producto miproducto) {
            String miRespuesta;
            Conexion miConexion = new Conexion();
            Connection nuevaCon;
            nuevaCon = miConexion.getConn();
           
            PreparedStatement sentencia;
           
            try {
                String Query = "INSERT INTO Producto (descripcion,precio,categorias_idcategorias,marcas_idmarcas)"
                        + " VALUES (?,?,?,?);";
                sentencia = nuevaCon.prepareStatement (Query);
                sentencia.setString (1,miproducto.getDescripcion());
                sentencia.setInt (2,miproducto.getPrecio());
                sentencia.setInt(3,miproducto.getCategorias_idcategorias());
                sentencia.setInt (4,miproducto.getMarcas_idmarcas());
                sentencia.execute();
                miRespuesta = ""; 
        } catch (Exception ex) {
        miRespuesta = ex.getMessage();
        System.err.println("Ocurrio un error en ProductoDAO" + ex.getMessage());
        }
    return miRespuesta;
    
    }

   public  Producto ConsultarProducto (int idproducto){
     Producto miproducto = null;
     Conexion miConexion = new Conexion ();
     Connection nuevaCon;
     nuevaCon = miConexion.getConn();
     
try{
    Statement sentencia = nuevaCon.createStatement();
    String queryproducto = "select idProducto,descripcion,precio,categorias_idcategorias,marcas_idmarcas" + "from Producto where idProducto = '" + idproducto + "';";
    ResultSet rs = sentencia.executeQuery(queryproducto);
    while (rs.next()){
        miproducto = new Producto();
        miproducto.setIdproducto(rs.getInt(1));
        miproducto.setDescripcion(rs.getString(2));
        miproducto.setPrecio(rs.getInt(3));
        miproducto.setCategorias_idcategorias(rs.getInt(4));
        miproducto.setMarcas_idmarcas(rs.getInt(5));
    }
    return miproducto;
} catch (Exception ex) {
    System.out.println("Error consulta ProductoDAO_ConsultarProducto\n" + ex.getMessage());
    return miproducto;
}
            
   }           


public String ActualizarProducto (Producto miproducto) {
    String miRespuesta;
    Conexion miConexion = new Conexion ();
    Connection nuevacon;
    nuevacon = miConexion.getConn();
    
    PreparedStatement sentencia;
    
    try{
        String query = "update producto set descripcion = ?, precio = ?, categorias_idcategorias = ?, marcas_idmarcas  = ?"+" where idproducto  = ? ;";
        sentencia = nuevacon.prepareStatement(query);
        
        sentencia.setString(1,miproducto.getDescripcion());
        sentencia.setInt(2,miproducto.getPrecio());
        sentencia.setInt(3,miproducto.getCategorias_idcategorias());
        sentencia.setInt(4,miproducto.getMarcas_idmarcas());
        sentencia.setInt(5,miproducto.getIdproducto());
        
        sentencia.executeUpdate ();
        System.out.println("Query" + sentencia.toString());
        miRespuesta = "";
    } catch (Exception ex){
        miRespuesta = ex.getMessage ();
        System.out.println("Error Actualizar ProductoDAO_ActualizarProducto\n" + ex.getMessage());
    }
    return miRespuesta;
    }
}